# Copyright (c) OpenMMLab. All rights reserved.
from .dwpose_distiller import DWPoseDistiller

__all__ = ['DWPoseDistiller']
