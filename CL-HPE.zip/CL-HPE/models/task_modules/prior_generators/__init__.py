# Copyright (c) OpenMMLab. All rights reserved.
from .mlvl_point_generator import MlvlPointGenerator  # noqa
