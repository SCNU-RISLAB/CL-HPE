# Copyright (c) OpenMMLab. All rights reserved.
from .assigners import *  # noqa
from .prior_generators import *  # noqa
